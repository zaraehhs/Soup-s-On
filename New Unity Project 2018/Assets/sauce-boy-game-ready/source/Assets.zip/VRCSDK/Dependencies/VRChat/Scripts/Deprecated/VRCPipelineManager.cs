﻿namespace VRC.Core
{
	public class VRCPipelineManager: PipelineManager 
	{} 
}
